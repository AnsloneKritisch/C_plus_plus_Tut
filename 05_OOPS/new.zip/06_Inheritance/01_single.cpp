#include <iostream>

using namespace std;


class veh
{
    public:

    int nc = 10 ;


    void show()
    {
        cout << " Didi: " << nc <<" cars" ;
    }
};

// derived class

class cars : public veh
{
    public:
    int sachin = 12 ;
};





int main()
{
    cars obj ;
    obj.show();
    
    return 0;
}
